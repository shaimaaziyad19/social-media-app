final Map<String, String> enUs = {
  'hi': 'Hi',
  'app_name': 'Rippl',
};
