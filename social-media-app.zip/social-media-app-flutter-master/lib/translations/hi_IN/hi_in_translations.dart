final Map<String, String> hiIn = {
  'hi': 'Hi',
  'app_name': 'Rippl',
};
